import fs from "fs";
import zlib from "zlib";

const source = fs.readFileSync("zlib-compress.mjs");
const result = zlib.gzipSync(source);

fs.writeFileSync("zlib-compress.mjs.gz", result);

console.info("File berhasil dikompresi menjadi zlib-compress.mjs.gz");